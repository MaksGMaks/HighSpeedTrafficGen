#include "Generator.hpp"

Generator::Generator(QObject *parent)
: isRunning(false)
, isPaused(false) {

    int nb_ports = rte_eth_dev_count_avail();
    if (nb_ports <= 0) {
        std::cerr << "[Generator] No DPDK ports available\n";
        return;
    }

    connect(this, &Generator::finished, this, &Generator::doStop);
}

Generator::~Generator() {
    std::cout << "[Generator::~Generator] stop thread and destroy object" << std::endl;
    doStop();
}

void Generator::doStart(const genParams& params) {
    std::cout << "[Generator::doStart] start thread" << std::endl;
    isRunning = true;
    isPaused = false;
    m_params = params;
    switch (params.mode) {
    case 1:
        if(params.fileSend) m_workerThread = std::thread(&Generator::pfringSendFile, this);
        else m_workerThread = std::thread(&Generator::pfringSend, this);
        break;
    case 2:
        if(params.fileSend) m_workerThread = std::thread(&Generator::pfringZCSendFile, this);
        else m_workerThread = std::thread(&Generator::pfringZCSend, this);
        break;
    case 4:
        if(params.fileSend) m_workerThread = std::thread(&Generator::dpdkSendFile, this);
        else m_workerThread = std::thread(&Generator::dpdkSend, this);
        break;
    default:
        break;
    }
}

void Generator::doStop() {
    std::cout << "[Generator::doStop] stop thread" << std::endl;
    {
        std::lock_guard lock(m_mutex);
        isRunning = false;
    }
    doResume();
    if(m_workerThread.joinable()) {
        m_workerThread.join();
    }
}

void Generator::doPause() {
    std::cout << "[Generator::doPause] pause thread" << std::endl;
    std::lock_guard lock(m_mutex);
    isPaused = true;
}

void Generator::doResume() {
    {
        std::lock_guard lock(m_mutex);
        isPaused = false;
    }
    m_pause.notify_all();
}

/**
 * @brief dpdkSend
 * @details Send packets using DPDK
 * @note DPDK is not supported on all interfaces. Check interface support before using.
*/
void Generator::dpdkSend() {
    uint16_t port_id;
    if (rte_eth_dev_get_port_by_name(m_params.interfaceName.c_str(), &port_id) != 0) {
        std::cerr << "DPDK: Failed to get port for device " << m_params.interfaceName << std::endl;
        emit sendError("DPDK: Failed to get port for device " + m_params.interfaceName);
        emit finished();
        return;
    }
    const uint16_t queue_id = 0;
    const uint16_t nb_txd = 1024;
    const uint32_t mbuf_size = m_params.packSize + RTE_PKTMBUF_HEADROOM;
    const uint32_t nb_mbufs = 8192;

    // Create mempool
    std::string pool_name = "MBUF_POOL_" + std::to_string(m_params.packSize);
    rte_mempool* mbuf_pool = rte_mempool_lookup(pool_name.c_str());

    if (!mbuf_pool) {
        mbuf_pool = rte_pktmbuf_pool_create(
            pool_name.c_str(), nb_mbufs, 256, 0, mbuf_size, rte_socket_id());
        
        if (!mbuf_pool) {
            std::cerr << "DPDK: Failed to create mbuf pool: " << rte_strerror(rte_errno) << std::endl;
            emit sendError("DPDK: Failed to create mbuf pool: " + std::string(rte_strerror(rte_errno)));
            emit finished();
            return;
        }
    }

    // Configure port
    rte_eth_conf port_conf = {};
    port_conf.rxmode.max_lro_pkt_size = RTE_ETHER_MAX_LEN;
    if (rte_eth_dev_configure(port_id, 0, 1, &port_conf) < 0) {
        std::cerr << "DPDK: Failed to configure port" << std::endl;
        emit sendError("DPDK: Failed to configure port " + std::to_string(port_id));
        emit finished();
        return;
    }
    if (rte_eth_tx_queue_setup(port_id, queue_id, nb_txd, rte_eth_dev_socket_id(port_id), nullptr) < 0) {
        std::cerr << "DPDK: Failed to setup TX queue" << std::endl;
        emit sendError("DPDK: Failed to setup TX queue for port " + std::to_string(port_id));
        emit finished();
        return;
    }
    if (rte_eth_dev_start(port_id) < 0) {
        std::cerr << "DPDK: Failed to start port" << std::endl;
        emit sendError("DPDK: Failed to start port " + std::to_string(port_id));
        emit finished();
        return;
    }

    std::vector<uint8_t> packet(m_params.packSize, m_params.packetPattern); // Dummy payload
    std::vector<rte_mbuf*> burst(m_params.burstSize);

    for (uint16_t i = 0; i < m_params.burstSize; ++i) {
        rte_mbuf* mbuf = rte_pktmbuf_alloc(mbuf_pool);
        if (!mbuf) {
            std::cerr << "DPDK: Failed to allocate mbuf\n";
            emit sendWarning("DPDK: Failed to allocate mbuf");
            burst.resize(i); // Only send what we have
            break;
        }
        uint8_t* data = rte_pktmbuf_mtod(mbuf, uint8_t*);
        memcpy(data, packet.data(), m_params.packSize);
        mbuf->data_len = m_params.packSize;
        mbuf->pkt_len = m_params.packSize;
        burst[i] = mbuf;
    }
    
    // Preset stop conditions
    uint64_t totalCopies = 0, totalSend = 0;
    struct timespec startTime{}, currTime{};
    
    // Preset speed variables
    uint64_t bytesPerPacket = m_params.packSize + 20;
    uint64_t internalNS = 1e9 * bytesPerPacket / m_params.speed;
    uint64_t nextTime, sleepNS;

    clock_gettime(CLOCK_MONOTONIC, &startTime);
    emit sendProgress(0, 0, {.tv_sec=0});
    nextTime = startTime.tv_sec * 1'000'000'000ULL + startTime.tv_nsec;
    while (isRunning) {
        {
            std::unique_lock lock(m_mutex);
            m_pause.wait(lock, [this](){ return !isPaused || !isRunning; });
        }

        if(!isRunning)
            break;

        // SEND
        uint16_t sent = rte_eth_tx_burst(port_id, queue_id, burst.data(), burst.size());
        if (sent < burst.size()) {
            std::cerr << "DPDK: Failed to send all packets. Sent: " << sent << std::endl;
            emit sendWarning("DPDK: Failed to send all packets. Sent: " + std::to_string(sent));
        }
        // END SEND

        clock_gettime(CLOCK_MONOTONIC, &currTime);
        totalCopies += sent;
        totalSend += packet.size() * sent;
        emit sendProgress(totalSend, totalCopies, currTime);
        if(((currTime.tv_sec - startTime.tv_sec) >= m_params.time && m_params.time != 0)  
            || (totalCopies == m_params.copies && m_params.copies != 0) 
            || (totalSend == m_params.totalSend && m_params.totalSend != 0))
            break;
        
        if(m_params.speed != 0) {
            nextTime += internalNS;
            if(nextTime < (currTime.tv_sec * 1'000'000'000ULL + currTime.tv_nsec))
                sleepNS = 0;
            else
                sleepNS = nextTime - (currTime.tv_sec * 1'000'000'000ULL + currTime.tv_nsec);
            if(sleepNS > 0) {
                struct timespec sleepTime = {
                    .tv_sec = sleepNS / 1'000'000'000ULL,
                    .tv_nsec = sleepNS % 1'000'000'000ULL
                };
                nanosleep(&sleepTime, nullptr);
            } else {
                nextTime = currTime.tv_sec * 1'000'000'000ULL + currTime.tv_nsec;
            }
        }
    }
    // Free mbufs
    for (uint16_t i = 0; i < burst.size(); ++i) {
        rte_pktmbuf_free(burst[i]);
    }
    
    rte_eth_dev_stop(port_id);
    emit finished();
} 

/**
 * @brief dpdkSendFile
 * @details Send file using DPDK
 * @note DPDK is not supported on all interfaces. Check interface support before using.
*/
void Generator::dpdkSendFile() {
    uint16_t port_id;
    if (rte_eth_dev_get_port_by_name(m_params.interfaceName.c_str(), &port_id) != 0) {
        std::cerr << "DPDK: Failed to get port for device " << m_params.interfaceName << std::endl;
        emit sendError("DPDK: Failed to get port for device " + m_params.interfaceName);
        emit finished();
        return;
    }
    const uint16_t queue_id = 0;
    const uint16_t nb_txd = 1024;
    const uint32_t mbuf_size = m_params.packSize + RTE_PKTMBUF_HEADROOM;
    const uint32_t nb_mbufs = 8192;

    // Create mempool
    std::string pool_name = "MBUF_POOL_" + std::to_string(m_params.packSize);
    rte_mempool* mbuf_pool = rte_mempool_lookup(pool_name.c_str());

    if (!mbuf_pool) {
        mbuf_pool = rte_pktmbuf_pool_create(
            pool_name.c_str(), nb_mbufs, 256, 0, mbuf_size, rte_socket_id());
        
        if (!mbuf_pool) {
            std::cerr << "DPDK: Failed to create mbuf pool: " << rte_strerror(rte_errno) << std::endl;
            emit sendError("DPDK: Failed to create mbuf pool: " + std::string(rte_strerror(rte_errno)));
            emit finished();
            return;
        }
    }

    // Configure port
    rte_eth_conf port_conf = {};
    port_conf.rxmode.max_lro_pkt_size = RTE_ETHER_MAX_LEN;
    if (rte_eth_dev_configure(port_id, 0, 1, &port_conf) < 0) {
        std::cerr << "DPDK: Failed to configure port" << std::endl;
        emit sendError("DPDK: Failed to configure port " + std::to_string(port_id));
        emit finished();
        return;
    }
    if (rte_eth_tx_queue_setup(port_id, queue_id, nb_txd, rte_eth_dev_socket_id(port_id), nullptr) < 0) {
        std::cerr << "DPDK: Failed to setup TX queue" << std::endl;
        emit sendError("DPDK: Failed to setup TX queue for port " + std::to_string(port_id));
        emit finished();
        return;
    }
    if (rte_eth_dev_start(port_id) < 0) {
        std::cerr << "DPDK: Failed to start port" << std::endl;
        emit sendError("DPDK: Failed to start port " + std::to_string(port_id));
        emit finished();
        return;
    }

    // Preset packet
    uint64_t offset = 0;
    std::vector<rte_mbuf*> burst(m_params.burstSize);

    std::ifstream file(m_params.filePath, std::ios::binary);
    if (!file) {
        std::cerr << "Failed to open file: " << m_params.filePath << std::endl;
        rte_eth_dev_stop(port_id);
        emit sendError("Failed to open file: " + m_params.filePath);
        emit finished();
        return;
    }
    file.seekg(0, std::ios::end);
    std::streamsize fileSize = file.tellg();
    file.seekg(0, std::ios::beg);
    std::vector<char> fileData(fileSize);
    if (!file.read((fileData.data()), fileSize)) {
        std::cerr << "Failed to read file." << std::endl;
        rte_eth_dev_stop(port_id);
        emit sendError("Failed to read file: " + m_params.filePath);
        emit finished();
        return;
    }
    std::vector<uint8_t> packet(fileData.begin(), fileData.end());
    if(fileSize % m_params.packSize != 0) {
        fileSize += m_params.packSize - (fileSize % m_params.packSize);
    }
    packet.resize(fileSize, 0x00);

    for (uint16_t i = 0; i < m_params.burstSize; ++i) {
        rte_mbuf* mbuf = rte_pktmbuf_alloc(mbuf_pool);
        if (!mbuf) {
            std::cerr << "DPDK: Failed to allocate mbuf\n";
            emit sendWarning("DPDK: Failed to allocate mbuf");
            burst.resize(i); // Only send what we have
            break;
        }
        uint8_t* data = rte_pktmbuf_mtod(mbuf, uint8_t*);
        memcpy(data, packet.data() + offset, m_params.packSize);
        mbuf->data_len = m_params.packSize;
        mbuf->pkt_len = m_params.packSize;
        burst[i] = mbuf;
        if((offset + m_params.packSize) >= fileSize - 1) {
            offset = 0;
        } else {
            offset += m_params.packSize;
        }
    }
    
    // Preset stop conditions
    uint64_t totalCopies = 0, totalSend = 0;
    struct timespec startTime{}, currTime{};
    
    // Preset speed variables
    uint64_t bytesPerPacket = m_params.packSize + 20;
    uint64_t internalNS = 1e9 * bytesPerPacket / m_params.speed;
    uint64_t nextTime, sleepNS;

    clock_gettime(CLOCK_MONOTONIC, &startTime);
    emit sendProgress(0, 0, {.tv_sec=0});
    nextTime = startTime.tv_sec * 1'000'000'000ULL + startTime.tv_nsec;
    while (isRunning) {
        {
            std::unique_lock lock(m_mutex);
            m_pause.wait(lock, [this](){ return !isPaused || !isRunning; });
        }

        if(!isRunning)
            break;

        // SEND
        uint16_t sent = rte_eth_tx_burst(port_id, queue_id, burst.data(), burst.size());
        if (sent < burst.size()) {
            std::cerr << "DPDK: Failed to send all packets. Sent: " << sent << std::endl;
            emit sendWarning("DPDK: Failed to send all packets. Sent: " + std::to_string(sent));
        }
        // END SEND

        clock_gettime(CLOCK_MONOTONIC, &currTime);
        totalCopies += sent;
        totalSend += packet.size() * sent;
        emit sendProgress(totalSend, totalCopies, currTime);
        if(((currTime.tv_sec - startTime.tv_sec) >= m_params.time && m_params.time != 0)  
            || (totalCopies == m_params.copies && m_params.copies != 0) 
            || (totalSend == m_params.totalSend && m_params.totalSend != 0))
            break;
        
        if(m_params.speed != 0) {
            nextTime += internalNS;
            if(nextTime < (currTime.tv_sec * 1'000'000'000ULL + currTime.tv_nsec))
                sleepNS = 0;
            else
                sleepNS = nextTime - (currTime.tv_sec * 1'000'000'000ULL + currTime.tv_nsec);
            if(sleepNS > 0) {
                struct timespec sleepTime = {
                    .tv_sec = sleepNS / 1'000'000'000ULL,
                    .tv_nsec = sleepNS % 1'000'000'000ULL
                };
                nanosleep(&sleepTime, nullptr);
            } else {
                nextTime = currTime.tv_sec * 1'000'000'000ULL + currTime.tv_nsec;
            }
        }
    }
    // Free mbufs
    for (uint16_t i = 0; i < burst.size(); ++i) {
        rte_pktmbuf_free(burst[i]);
    }
    
    rte_eth_dev_stop(port_id);
    emit finished();
}